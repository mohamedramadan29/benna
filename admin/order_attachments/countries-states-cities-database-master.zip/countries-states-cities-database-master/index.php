<?php

echo 'Welcome to Country State City Database';
